(function courseRuntime(course, version, preview = false, logoUrl = "") {
  const root = document.getElementById("course");
  const pages = course.modules.flatMap((m) => m.pages);
  const allBlocks = pages.flatMap((p) => p.blocks);
  const game = course.gamification || {
    readingXP: 50,
    activityXP: 75,
    quizXP: 100,
    challengeXP: 200,
    levels: [
      { name: "Explorador", xp: 0 },
      { name: "Criador", xp: 300 },
      { name: "Especialista", xp: 800 }
    ],
    challenges: []
  };
  let api = null;
  let initialized = false;
  let ended = false;
  const start = Date.now();
  let pageIndex = 0;
  let key = (preview ? "scorm-preview-" : "scorm-progress-") + course.id;
  let state = {
    courseId: course.id,
    completed: [],
    attempts: [],
    seconds: 0,
    location: "",
    watched: {},
    answers: {},
    coverage: {}
  };
  function discover(w) {
    for (let n = 0; n < 20 && w; n++) {
      try {
        const a = w[version === "1.2" ? "API" : "API_1484_11"];
        if (a) return a;
        if (w.parent === w) break;
        w = w.parent;
      } catch {
        break;
      }
    };
    return null;
  }
  if (!preview) {
    api = discover(window);
    if (!api) {
      try {
        api = discover(window.opener);
      } catch {
      }
    }
  };
  function call(name, ...args) {
    try {
      if (!api) return "";
      return api[name](...args);
    } catch {
      notice("A comunicação com o LMS falhou. Sua cópia local foi preservada.");
      return "";
    }
  }
  const names = version === "1.2" ? [
    "LMSInitialize",
    "LMSGetValue",
    "LMSSetValue",
    "LMSCommit",
    "LMSFinish"
  ] : ["Initialize", "GetValue", "SetValue", "Commit", "Terminate"];
  const get = (k) => call(names[1], k);
  const set = (k, v) => {
    if (initialized && String(call(names[2], k, String(v))) !== "true")
      notice(
        "O LMS recusou o campo " + k + ". Sua cópia local foi preservada."
      );
  };
  function notice(message) {
    const el2 = document.getElementById("runtime-message");
    if (el2) el2.textContent = message;
  }
  if (api) {
    initialized = String(call(names[0], "")) === "true";
    if (initialized)
      key += "-" + get(version === "1.2" ? "cmi.core.student_id" : "cmi.learner_id");
  };
  try {
    const saved = initialized ? get("cmi.suspend_data") : localStorage.getItem(key);
    if (saved) {
      const p = JSON.parse(saved);
      const belongsToCourse = !p.courseId || p.courseId === course.id;
      if (belongsToCourse && p.v === 2) {
        state.completed = p.c.map((i) => pages[i]?.id).filter(Boolean);
        state.location = pages[p.l]?.id || "";
        state.seconds = p.s;
        state.watched = Object.fromEntries(
          (p.w || []).map(([i, value]) => [
            allBlocks[i]?.id,
            value
          ])
        );
        state.answers = Object.fromEntries(
          (p.a || []).map((i) => [allBlocks[i]?.id, "completed"])
        );
        state.attempts = (p.q || []).flatMap(
          ([i, count, score]) => Array.from({ length: count }, () => ({
            blockId: allBlocks[i]?.id,
            score,
            answer: [],
            time: 0,
            date: ""
          }))
        );
      };
      if (belongsToCourse && Array.isArray(p.completed) && Array.isArray(p.attempts))
        state = { ...state, ...p };
    }
  } catch {
  };
  const pageIds = new Set(pages.map((p) => p.id));
  const blockIds = new Set(allBlocks.map((b) => b.id));
  const answerIds = new Set(
    allBlocks.flatMap((b) => [
      b.id,
      b.id + "-marks",
      ...(b.cues || []).map((cue) => cue.id)
    ])
  );
  state.courseId = course.id;
  state.completed = [
    ...new Set(
      (Array.isArray(state.completed) ? state.completed : []).filter(
        (id) => typeof id === "string" && pageIds.has(id)
      )
    )
  ];
  state.attempts = (Array.isArray(state.attempts) ? state.attempts : []).filter(
    (attempt) => attempt && blockIds.has(attempt.blockId) && (attempt.score === null || Number.isFinite(attempt.score))
  );
  state.watched = Object.fromEntries(
    Object.entries(state.watched || {}).filter(
      ([id, value]) => blockIds.has(id) && Number.isFinite(value)
    )
  );
  state.coverage = Object.fromEntries(
    Object.entries(state.coverage || {}).filter(
      ([id, value]) => blockIds.has(id) && Array.isArray(value)
    )
  );
  state.answers = Object.fromEntries(
    Object.entries(state.answers || {}).filter(([id]) => answerIds.has(id))
  );
  state.seconds = Math.max(0, Number(state.seconds) || 0);
  if (!pageIds.has(state.location)) state.location = pages[0]?.id || "";
  const sessionBase = Number(state.seconds) || 0;
  pageIndex = Math.max(
    0,
    pages.findIndex((p) => p.id === state.location)
  );
  function stats() {
    const completedPages = pages.filter(
      (p) => state.completed.includes(p.id)
    );
    const latest = /* @__PURE__ */ new Map();
    state.attempts.forEach((a) => {
      if (a.score !== null) latest.set(a.blockId, a);
    });
    let total = 0, weights = 0;
    latest.forEach((a) => {
      const b = allBlocks.find((b2) => b2.id === a.blockId);
      if (!b) return;
      const w = b.weight || 1;
      total += a.score * w;
      weights += w;
    });
    const score = weights ? Math.round(total / weights) : 0;
    const challenges = game.challenges.filter((challenge) => {
      const m = course.modules.find((m2) => m2.id === challenge.moduleId);
      return m?.pages.length && m.pages.every((p) => state.completed.includes(p.id));
    });
    const xp = completedPages.reduce(
      (n, page) => n + (page.kind === "activity" ? game.activityXP : game.readingXP),
      0
    ) + [...latest.values()].filter(
      (a) => a.score >= (allBlocks.find((b) => b.id === a.blockId)?.passScore || 70)
    ).length * game.quizXP + challenges.length * game.challengeXP;
    const level = [...game.levels].sort((a, b) => b.xp - a.xp).find((l) => xp >= l.xp)?.name || "Explorador";
    return {
      score,
      xp,
      level,
      challenges,
      completedCount: completedPages.length,
      progress: pages.length ? Math.min(1, completedPages.length / pages.length) : 0,
      graded: weights > 0
    };
  }
  function save() {
    if (ended) return;
    state.seconds = sessionBase + Math.round((Date.now() - start) / 1e3);
    state.location = pages[pageIndex]?.id || "";
    const serialized = JSON.stringify(state);
    try {
      localStorage.setItem(key, serialized);
    } catch {
      notice("Armazenamento local indisponível.");
    };
    if (!initialized) return;
    const s = stats();
    const complete = s.progress >= 1;
    const hasQuestions = pages.some(
      (p) => p.blocks.some(
        (b) => b.type === "quiz" || ["ordering", "dragdrop"].includes(b.type)
      )
    );
    set(
      version === "1.2" ? "cmi.core.lesson_location" : "cmi.location",
      state.location
    );
    set(version === "1.2" ? "cmi.core.score.raw" : "cmi.score.raw", s.score);
    set(version === "1.2" ? "cmi.core.score.min" : "cmi.score.min", 0);
    set(version === "1.2" ? "cmi.core.score.max" : "cmi.score.max", 100);
    if (version === "1.2")
      set(
        "cmi.core.lesson_status",
        complete ? hasQuestions ? s.score >= course.passScore ? "passed" : "failed" : "completed" : "incomplete"
      );
    else {
      set("cmi.completion_status", complete ? "completed" : "incomplete");
      set(
        "cmi.success_status",
        hasQuestions && s.graded ? s.score >= course.passScore ? "passed" : "failed" : "unknown"
      );
      set("cmi.progress_measure", s.progress.toFixed(4));
      set("cmi.score.scaled", (s.score / 100).toFixed(4));
      set("cmi.objectives.0.id", "course-mastery");
      set("cmi.objectives.0.score.scaled", (s.score / 100).toFixed(4));
      set(
        "cmi.objectives.0.success_status",
        s.score >= course.passScore ? "passed" : "failed"
      );
    };
    const summary = allBlocks.map((b, i) => {
      const attempts = state.attempts.filter((a) => a.blockId === b.id);
      return attempts.length ? [i, attempts.length, attempts.at(-1).score] : null;
    }).filter(Boolean);
    const compact = JSON.stringify({
      v: 2,
      courseId: course.id,
      c: state.completed.map(
        (id) => pages.findIndex((p) => p.id === id)
      ),
      l: pageIndex,
      s: state.seconds,
      q: summary,
      w: Object.entries(state.watched).map(([id, value]) => [
        allBlocks.findIndex((b) => b.id === id),
        value
      ]),
      a: allBlocks.map(
        (b, i) => state.answers[b.id] === "completed" ? i : null
      ).filter((x) => x !== null)
    });
    const resume = serialized.length <= (version === "1.2" ? 4096 : 64e3) ? serialized : compact;
    if (resume.length <= (version === "1.2" ? 4096 : 64e3))
      set("cmi.suspend_data", resume);
    else
      notice(
        "O histórico excedeu o limite de retomada do SCORM. A cópia completa está salva neste navegador."
      );
    const secs = Math.round((Date.now() - start) / 1e3);
    set(
      version === "1.2" ? "cmi.core.session_time" : "cmi.session_time",
      version === "1.2" ? String(Math.floor(secs / 3600)).padStart(4, "0") + ":" + String(Math.floor(secs % 3600 / 60)).padStart(2, "0") + ":" + String(secs % 60).padStart(2, "0") + ".00" : "PT" + secs + "S"
    );
    set(
      version === "1.2" ? "cmi.core.exit" : "cmi.exit",
      complete ? "" : "suspend"
    );
    if (String(call(names[3], "")) !== "true")
      notice("O LMS ainda não confirmou o salvamento.");
  }
  function finish() {
    if (ended) return;
    save();
    if (initialized) call(names[4], "");
    ended = true;
  }
  window.addEventListener("pagehide", finish);
  window.addEventListener("beforeunload", finish);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") save();
  });
  setInterval(save, 3e4);
  function el(tag, text, cls) {
    const e = document.createElement(tag);
    if (text !== void 0) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  }
  function button(text, fn) {
    const b = el("button", text);
    b.type = "button";
    b.onclick = fn;
    return b;
  }
  function safeUrl(url) {
    return /^(https?:|data:(image|audio|video|application\/pdf)|media\/)/i.test(
      url
    ) ? url : "";
  }
  function input(label, type = "text") {
    const wrap = el("label", label);
    const field = document.createElement("input");
    field.type = type;
    wrap.append(field);
    return { wrap, field };
  }
  function interaction(b, answer, score, elapsed) {
    const a = {
      blockId: b.id,
      answer,
      score,
      time: elapsed,
      date: (/* @__PURE__ */ new Date()).toISOString()
    };
    state.attempts.push(a);
    if (initialized) {
      const index = Number(get("cmi.interactions._count")) || 0;
      const base = "cmi.interactions." + index;
      set(
        base + ".id",
        b.id + "-attempt-" + state.attempts.filter((x) => x.blockId === b.id).length
      );
      const type = b.questionType === "boolean" ? "true-false" : b.questionType === "single" || b.questionType === "multiple" ? "choice" : b.questionType === "ordering" ? "sequencing" : b.questionType === "matching" ? "matching" : "fill-in";
      set(base + ".type", type);
      const encode = (value) => {
        const i = b.items.findIndex((item) => item.id === value);
        return i < 0 ? value : i.toString(36);
      };
      const delimiter = version === "1.2" ? "," : "[,]";
      const response = b.questionType === "boolean" ? version === "1.2" ? answer[0] === "true" ? "t" : "f" : answer[0] : b.questionType === "matching" ? answer.map(
        (id, i) => i.toString(36) + (version === "1.2" ? "." : "[.]") + encode(id)
      ).join(delimiter) : answer.map(encode).join(delimiter);
      set(
        base + (version === "1.2" ? ".student_response" : ".learner_response"),
        response.slice(0, version === "1.2" ? 255 : 4e3)
      );
      set(
        base + ".result",
        score === null ? "neutral" : score >= b.passScore ? "correct" : version === "1.2" ? "wrong" : "incorrect"
      );
      set(base + ".weighting", b.weight);
      set(
        base + ".latency",
        version === "1.2" ? "0000:" + String(Math.floor(elapsed / 60) % 60).padStart(2, "0") + ":" + String(elapsed % 60).padStart(2, "0") + ".00" : "PT" + elapsed + "S"
      );
      if (version !== "1.2") set(base + ".description", b.title.slice(0, 250));
    };
    save();
  }
  function quiz(b, container) {
    const attempts = state.attempts.filter((a) => a.blockId === b.id);
    const last = attempts.at(-1);
    container.append(
      el(
        "p",
        `${attempts.length}/${b.attempts} tentativas · aprovação ${b.passScore}%${b.timeLimit ? " · " + b.timeLimit + " segundos" : ""}`,
        "muted"
      )
    );
    if (last) container.append(el("p", "Última nota: " + last.score + "%"));
    let answer = [];
    const began = Date.now();
    const form = el("form");
    const status = el("p");
    status.setAttribute("role", "status");
    if (["single", "multiple", "boolean"].includes(b.questionType)) {
      const opts = b.questionType === "boolean" ? [
        { id: "true", title: "Verdadeiro" },
        { id: "false", title: "Falso" }
      ] : b.items;
      opts.forEach((item) => {
        const { wrap, field } = input(
          item.title,
          b.questionType === "multiple" ? "checkbox" : "radio"
        );
        field.name = b.id;
        field.value = item.id;
        field.onchange = () => {
          answer = b.questionType === "multiple" ? Array.from(
            form.querySelectorAll("input:checked")
          ).map((x) => x.value) : [field.value];
        };
        form.append(wrap);
      });
    } else if (b.questionType === "matching") {
      const bank = el("div", void 0, "drag-bank");
      [...b.items].reverse().forEach((item) => {
        const token = el("span", item.detail, "drag-token");
        token.draggable = true;
        token.ondragstart = (e) => e.dataTransfer?.setData("text/plain", item.id);
        bank.append(token);
      });
      form.append(
        el(
          "p",
          "Arraste uma resposta para o conceito ou use a lista de seleção."
        ),
        bank
      );
      b.items.forEach((item) => {
        const label = el("label", item.title);
        const select = document.createElement("select");
        select.append(new Option("Selecione", ""));
        [...b.items].reverse().forEach(
          (target) => select.append(new Option(target.detail, target.id))
        );
        select.onchange = () => {
          answer = b.items.map(
            (_, i) => form.querySelectorAll("select")[i].value
          );
        };
        label.ondragover = (e) => e.preventDefault();
        label.ondrop = (e) => {
          e.preventDefault();
          const id = e.dataTransfer?.getData("text/plain") || "";
          if (b.items.some((x) => x.id === id)) {
            select.value = id;
            select.dispatchEvent(new Event("change"));
          }
        };
        label.append(select);
        form.append(label);
      });
    } else if (b.questionType === "ordering") {
      let order = [...b.items].reverse();
      const list = el("div");
      const render2 = () => {
        list.replaceChildren();
        order.forEach((item, i) => {
          const row = el("div", item.title, "order-row");
          row.draggable = true;
          row.ondragstart = (e) => e.dataTransfer?.setData("text/plain", String(i));
          row.ondragover = (e) => e.preventDefault();
          row.ondrop = (e) => {
            e.preventDefault();
            const from = Number(e.dataTransfer?.getData("text/plain"));
            order.splice(i, 0, order.splice(from, 1)[0]);
            render2();
          };
          row.append(
            button("↑", () => {
              if (i) {
                [order[i - 1], order[i]] = [order[i], order[i - 1]];
                render2();
              }
            }),
            button("↓", () => {
              if (i < order.length - 1) {
                [order[i + 1], order[i]] = [order[i], order[i + 1]];
                render2();
              }
            })
          );
          list.append(row);
        });
        answer = order.map((i) => i.id);
      };
      render2();
      form.append(list);
    } else {
      const field = document.createElement("textarea");
      field.rows = 4;
      field.setAttribute("aria-label", "Sua resposta");
      field.placeholder = "Complete a lacuna";
      field.oninput = () => answer = [field.value];
      form.append(field);
    };
    const submit = el("button", "Enviar resposta");
    submit.type = "submit";
    submit.disabled = attempts.length >= b.attempts;
    form.onsubmit = (e) => {
      e.preventDefault();
      if (state.attempts.filter((a2) => a2.blockId === b.id).length >= b.attempts) {
        status.textContent = "Você atingiu o limite de tentativas.";
        return;
      };
      if (!answer.length || answer.some((x) => !x.trim())) {
        status.textContent = "Responda antes de enviar.";
        return;
      };
      const elapsed = Math.round((Date.now() - began) / 1e3);
      const correct = b.questionType === "ordering" ? b.items.map((i) => i.id) : b.questionType === "matching" ? b.items.map((i) => i.id) : b.correct;
      const normalize = (s) => s.trim().toLowerCase();
      const a = b.questionType === "multiple" ? [...answer].sort() : answer;
      const c = b.questionType === "multiple" ? [...correct].sort() : correct;
      let score = a.map(normalize).join("|") === c.map(normalize).join("|") ? 100 : 0;
      if (b.timeLimit && elapsed > b.timeLimit) score = 0;
      interaction(b, answer, score, elapsed);
      quizRefresh();
    };
    function quizRefresh() {
      container.replaceChildren(el("h2", b.title));
      quiz(b, container);
    }
    form.append(submit, status);
    container.append(form);
    if (last) container.append(el("p", b.feedback, "feedback"));
  }
  function block(b) {
    const card = el("section", void 0, "block");
    card.append(el("h2", b.title));
    const cueArea = el("div", void 0, "cue-area");
    const showCue = (cue, resume) => {
      if (state.answers[cue.id]) return;
      cueArea.replaceChildren(el("h3", cue.question));
      const field = document.createElement("input");
      field.setAttribute("aria-label", cue.question);
      const result = el("p");
      result.setAttribute("role", "status");
      cueArea.append(
        field,
        button("Responder", () => {
          if (!field.value.trim()) return;
          if (cue.answer && field.value.trim().toLowerCase() !== cue.answer.trim().toLowerCase()) {
            result.textContent = "Revise sua resposta e tente novamente.";
            return;
          };
          state.answers[cue.id] = field.value;
          result.textContent = "Resposta registrada.";
          save();
          resume?.();
        }),
        result
      );
    };
    switch (b.type) {
      case "heading":
        card.classList.add("hero");
        card.append(el("p", b.body));
        break;
      case "text": {
        const content = el("div");
        content.innerHTML = b.body;
        content.querySelectorAll("script,iframe,object,embed,style").forEach((x) => x.remove());
        content.querySelectorAll("*").forEach(
          (x) => Array.from(x.attributes).forEach((a) => {
            if (a.name.startsWith("on") || /^(href|src)$/i.test(a.name) && !safeUrl(a.value))
              x.removeAttribute(a.name);
          })
        );
        card.append(content);
        break;
      }
      case "quote":
        card.append(el("blockquote", b.body));
        break;
      case "code": {
        const pre = el("pre");
        pre.append(el("code", b.body));
        card.append(pre);
        break;
      }
      case "formula":
        {
          const formula = el("div", void 0, "formula");
          if (b.formulaHtml) formula.innerHTML = b.formulaHtml;
          else formula.textContent = b.body;
          card.append(formula);
        }
        break;
      case "table": {
        const table = el("table");
        b.body.split("\n").forEach((line, i) => {
          const row = el("tr");
          line.split("|").forEach((cell) => row.append(el(i ? "td" : "th", cell)));
          table.append(row);
        });
        card.append(table);
        break;
      }
      case "image": {
        const img = document.createElement("img");
        img.src = safeUrl(b.url);
        img.alt = b.alt;
        card.append(img);
        break;
      }
      case "link": {
        const a = el("a", b.body || "Abrir recurso");
        a.href = safeUrl(b.url);
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        card.append(a);
        break;
      }
      case "video":
      case "audio": {
        const watchedLabel = el(
          "p",
          "Assistido: " + (state.watched[b.id] || 0) + "%"
        );
        const covered = new Set(state.coverage[b.id] || []);
        let previous = -1;
        let lastTick = Date.now();
        const track = (seconds, duration, pause, resume) => {
          const elapsed = (Date.now() - lastTick) / 1e3;
          const delta = seconds - previous;
          if (previous >= 0 && delta > 0 && delta <= Math.max(2, elapsed * 1.5)) {
            for (let s = Math.floor(previous); s < Math.floor(seconds); s++)
              covered.add(s);
          };
          previous = seconds;
          lastTick = Date.now();
          state.coverage[b.id] = [...covered];
          if (duration > 0) {
            state.watched[b.id] = Math.max(
              state.watched[b.id] || 0,
              Math.min(100, Math.round(covered.size / duration * 100))
            );
            watchedLabel.textContent = "Assistido: " + state.watched[b.id] + "%";
          };
          const cue = (b.cues || []).find(
            (c) => seconds >= c.seconds && !state.answers[c.id]
          );
          if (cue) {
            pause();
            showCue(cue, resume);
          }
        };
        let external = null;
        try {
          external = new URL(b.url);
        } catch {
        };
        const youtube = external && [
          "youtube.com",
          "www.youtube.com",
          "youtu.be",
          "www.youtube-nocookie.com"
        ].includes(external.hostname);
        const vimeo = external && ["vimeo.com", "www.vimeo.com", "player.vimeo.com"].includes(
          external.hostname
        );
        if (youtube || vimeo) {
          const frame = document.createElement("iframe");
          frame.title = b.title;
          frame.height = "380";
          frame.allow = "fullscreen; autoplay";
          frame.allowFullscreen = true;
          const path = external.pathname.split("/").filter(Boolean);
          const id = youtube ? external.searchParams.get("v") || path.at(-1) : path.at(-1);
          if (id && /^[a-zA-Z0-9_-]+$/.test(id)) {
            frame.src = youtube ? "https://www.youtube-nocookie.com/embed/" + id + "?enablejsapi=1" : "https://player.vimeo.com/video/" + id + "?api=1";
            card.append(frame);
            const origin = youtube ? "https://www.youtube-nocookie.com" : "https://player.vimeo.com";
            const send = (method) => frame.contentWindow?.postMessage(
              JSON.stringify(
                youtube ? { event: "command", func: method, args: [] } : { method }
              ),
              origin
            );
            const receive = (e) => {
              if (e.source !== frame.contentWindow || e.origin !== origin)
                return;
              let data = e.data;
              try {
                if (typeof data === "string") data = JSON.parse(data);
              } catch {
                return;
              };
              if (youtube && data.event === "infoDelivery" && data.info?.currentTime !== void 0)
                track(
                  data.info.currentTime,
                  data.info.duration || 0,
                  () => send("pauseVideo"),
                  () => send("playVideo")
                );
              if (vimeo && data.event === "timeupdate")
                track(
                  data.data.seconds,
                  data.data.duration,
                  () => send("pause"),
                  () => send("play")
                );
            };
            window.addEventListener("message", receive);
            frame.onload = () => {
              if (youtube)
                frame.contentWindow?.postMessage(
                  JSON.stringify({
                    event: "listening",
                    id: b.id,
                    channel: "studio"
                  }),
                  origin
                );
              else
                frame.contentWindow?.postMessage(
                  JSON.stringify({
                    method: "addEventListener",
                    value: "timeupdate"
                  }),
                  origin
                );
            };
          };
          const link = el(
            "a",
            "Assistir ao vídeo externo"
          );
          link.href = safeUrl(b.url);
          link.target = "_blank";
          link.rel = "noopener noreferrer";
          card.append(
            link,
            el(
              "p",
              "Se o provedor bloquear o player incorporado, abra o vídeo no site e confirme a visualização."
            )
          );
          card.append(
            button("Confirmar que assisti", () => {
              state.watched[b.id] = 100;
              save();
              render();
            })
          );
        } else {
          const media = document.createElement(b.type);
          media.controls = true;
          media.preload = "metadata";
          media.src = safeUrl(b.url);
          if (b.captions) {
            const captions = document.createElement("track");
            captions.kind = "captions";
            captions.label = "Português";
            captions.srclang = "pt-BR";
            captions.default = true;
            captions.src = "data:text/vtt;charset=utf-8," + encodeURIComponent(b.captions);
            media.append(captions);
          };
          media.ontimeupdate = () => {
            if (isFinite(media.duration))
              track(
                media.currentTime,
                media.duration,
                () => media.pause(),
                () => {
                  media.play().catch(() => {
                  });
                }
              );
          };
          media.onended = () => {
            save();
          };
          card.append(media);
        };
        card.append(watchedLabel, cueArea);
        if (b.alt) card.append(el("p", b.alt));
        break;
      }
      case "pdf": {
        const frame = document.createElement("iframe");
        frame.title = b.title;
        frame.src = safeUrl(b.url);
        frame.height = "520";
        card.append(frame);
        const notes = document.createElement("textarea");
        notes.placeholder = "Suas anotações sobre o documento";
        notes.setAttribute("aria-label", "Anotações do PDF");
        notes.value = state.answers[b.id] || "";
        notes.onchange = () => {
          state.answers[b.id] = notes.value;
          save();
        };
        card.append(notes);
        const marks = el("div");
        const pageNumber = input("Página do PDF", "number");
        pageNumber.field.min = "1";
        pageNumber.field.value = "1";
        const selection = input("Trecho / marcação");
        const markList = el("ul");
        const renderMarks = () => {
          markList.replaceChildren();
          (state.answers[b.id + "-marks"] || []).forEach(
            (mark) => markList.append(el("li", "Página " + mark.page + ": " + mark.text))
          );
        };
        renderMarks();
        marks.append(
          pageNumber.wrap,
          selection.wrap,
          button("Salvar marcação", () => {
            if (!selection.field.value.trim()) return;
            state.answers[b.id + "-marks"] = [
              ...state.answers[b.id + "-marks"] || [],
              {
                page: Math.max(1, +pageNumber.field.value),
                text: selection.field.value
              }
            ];
            selection.field.value = "";
            save();
            renderMarks();
          }),
          markList
        );
        card.append(marks);
        (b.cues || []).forEach((cue) => {
          const area = el("div");
          area.append(button(cue.question, () => showCue(cue)));
          card.append(area);
        });
        card.append(cueArea);
        break;
      }
      case "quiz":
        card.replaceChildren(el("h2", b.title));
        quiz(b, card);
        break;
      case "flashcards":
        b.items.forEach((i) => {
          let back = false;
          const flip = button(i.title, () => {
            back = !back;
            flip.textContent = back ? i.detail : i.title;
            flip.setAttribute("aria-pressed", String(back));
          });
          flip.className = "flashcard";
          flip.setAttribute("aria-pressed", "false");
          card.append(flip);
        });
        break;
      case "timeline": {
        const list = el("ol", void 0, "timeline");
        b.items.forEach((i) => {
          const li = el("li");
          li.append(el("h3", i.title), el("p", i.detail));
          if (i.date) li.prepend(el("time", i.date));
          if (i.image) {
            const image = document.createElement("img");
            image.src = safeUrl(i.image);
            image.alt = i.title;
            li.append(image);
          };
          list.append(li);
        });
        card.append(list);
        break;
      }
      case "hotspot": {
        const stage = el("div", void 0, "hotspot");
        const img = document.createElement("img");
        img.src = safeUrl(b.url);
        img.alt = b.alt;
        stage.append(img);
        const info = el("p", "Selecione um ponto para explorar.");
        info.setAttribute("role", "status");
        b.items.forEach((i, n) => {
          const dot = button(
            String(n + 1),
            () => info.textContent = i.title + ": " + i.detail
          );
          dot.style.left = (i.x ?? 25 + n * 30) + "%";
          dot.style.top = (i.y ?? 50) + "%";
          dot.setAttribute("aria-label", i.title);
          stage.append(dot);
        });
        card.append(stage, info);
        (b.cues || []).forEach(
          (cue) => card.append(button(cue.question, () => showCue(cue)))
        );
        card.append(cueArea);
        break;
      }
      case "ordering":
      case "dragdrop":
        quiz(
          {
            ...b,
            type: "quiz",
            questionType: b.type === "ordering" ? "ordering" : "matching"
          },
          card
        );
        break;
      case "scenario": {
        let current = b.items[0];
        const scene = el("div");
        const visited = /* @__PURE__ */ new Set();
        const draw = () => {
          scene.replaceChildren();
          if (!current) {
            scene.append(el("p", "Cenário concluído."));
            return;
          };
          visited.add(current.id);
          scene.append(el("h3", current.title), el("p", current.detail));
          const next = current.choices?.length ? current.choices : current.target ? [{ label: "Continuar", target: current.target }] : [];
          next.forEach(
            (i) => scene.append(
              button(i.label, () => {
                current = b.items.find((x) => x.id === i.target);
                draw();
              })
            )
          );
          if (!next.length) {
            state.answers[b.id] = "completed";
            save();
            scene.append(
              el(
                "p",
                "Fim deste percurso. Reflita sobre as consequências de suas escolhas."
              ),
              button("Explorar novamente", () => {
                current = b.items[0];
                draw();
              })
            );
          };
          scene.append(el("small", visited.size + " situações exploradas"));
        };
        draw();
        card.append(scene);
        break;
      }
      default:
        card.append(el("p", b.body));
    };
    return card;
  }
  function render() {
    root.replaceChildren();
    const s = stats();
    const top = el("header");
    top.append(
      el("div", "SCORM STUDIO / EXPERIÊNCIA DE APRENDIZAGEM", "eyebrow"),
      el("h1", course.title),
      el("p", course.description)
    );
    const meter = document.createElement("progress");
    meter.max = 100;
    meter.value = Math.round(s.progress * 100);
    meter.setAttribute("aria-label", "Progresso do curso");
    top.append(
      meter,
      el(
        "p",
        `${Math.round(s.progress * 100)}% concluído · ${s.xp} XP · ${s.level} · Nota ${s.score}% · ${Math.floor(state.seconds / 60)} min · ${s.completedCount}/${pages.length} páginas`
      )
    );
    const badges = course.badges.filter(
      (b) => s.completedCount >= b.threshold
    );
    top.append(el("p", badges.map((b) => "🏅 " + b.name).join(" · ")));
    badges.filter((b) => b.image).forEach((b) => {
      const img = document.createElement("img");
      img.src = safeUrl(b.image);
      img.alt = b.name + ": " + b.description;
      img.width = 48;
      img.height = 48;
      top.append(img);
    });
    s.challenges.forEach(
      (c) => top.append(el("p", "✓ Desafio: " + c.name))
    );
    root.append(top);
    const message = el("p", void 0, "message");
    message.id = "runtime-message";
    message.setAttribute("role", "status");
    root.append(message);
    if (!preview && !initialized) notice("Modo local: nenhum LMS conectado.");
    const nav = el("nav");
    nav.setAttribute("aria-label", "Páginas do curso");
    pages.forEach((p, i) => {
      const b = button(
        (state.completed.includes(p.id) ? "✓ " : "") + p.title,
        () => {
          save();
          pageIndex = i;
          render();
        }
      );
      if (i === pageIndex) b.setAttribute("aria-current", "page");
      nav.append(b);
    });
    root.append(nav);
    const page = pages[pageIndex];
    if (!page) {
      root.append(el("p", "Este curso ainda não possui páginas."));
      return;
    };
    const main = el("main");
    main.append(
      el("p", `PÁGINA ${pageIndex + 1} DE ${pages.length}`, "eyebrow"),
      el("h1", page.title)
    );
    const speechStatus = el("span", void 0, "muted");
    speechStatus.setAttribute("role", "status");
    const speechTools = el("div", void 0, "speech-tools");
    speechTools.append(
      button("🔊 Ouvir esta página", () => {
        const synth = window.speechSynthesis;
        const Utterance = window.SpeechSynthesisUtterance;
        if (!synth || !Utterance) {
          speechStatus.textContent = "A leitura em voz alta não está disponível neste navegador.";
          return;
        };
        synth.cancel();
        const text = Array.from(
          main.querySelectorAll("h1,h2,h3,p,blockquote,li,th,td")
        ).map((node) => node.textContent?.trim()).filter(Boolean).join(". ");
        const utterance = new Utterance(text);
        utterance.lang = course.language || "pt-BR";
        const voices = synth.getVoices?.() || [];
        const exact = voices.find(
          (voice) => voice.lang.toLowerCase() === utterance.lang.toLowerCase()
        );
        const language = voices.find(
          (voice) => voice.lang.toLowerCase().startsWith(utterance.lang.slice(0, 2).toLowerCase())
        );
        utterance.voice = exact || language || null;
        utterance.onend = () => speechStatus.textContent = "Leitura concluída.";
        utterance.onerror = () => speechStatus.textContent = "Não foi possível concluir a leitura.";
        speechStatus.textContent = "Leitura em andamento…";
        synth.speak(utterance);
      }),
      button("Parar leitura", () => {
        window.speechSynthesis?.cancel();
        speechStatus.textContent = "Leitura interrompida.";
      }),
      speechStatus
    );
    main.append(speechTools);
    page.blocks.forEach((b) => main.append(block(b)));
    const feedback = el("p");
    feedback.setAttribute("role", "status");
    main.append(feedback);
    main.append(
      button(
        state.completed.includes(page.id) ? "Concluída ✓" : "Concluir e continuar →",
        () => {
          const missing = page.blocks.find(
            (b) => b.required && (["quiz", "dragdrop", "ordering"].includes(b.type) && !state.attempts.some((a) => a.blockId === b.id) || ["video", "audio"].includes(b.type) && (state.watched[b.id] || 0) < b.watchedPercent)
          );
          if (missing) {
            feedback.textContent = "Conclua a atividade: " + missing.title;
            return;
          };
          if (!state.completed.includes(page.id)) state.completed.push(page.id);
          if (pageIndex < pages.length - 1) pageIndex++;
          save();
          render();
          window.scrollTo(0, 0);
        }
      )
    );
    if (s.progress >= 1 && course.certificate && (!s.graded || s.score >= course.passScore)) {
      main.append(
        button("Imprimir certificado", () => {
          const cert = el("section", void 0, "certificate");
          cert.append(
            el("h1", "Certificado de conclusão"),
            el("p", "Concluiu o curso " + course.title),
            el("p", (/* @__PURE__ */ new Date()).toLocaleDateString("pt-BR")),
            el("p", course.author)
          );
          main.append(cert);
          window.print();
          cert.remove();
        })
      );
    };
    root.append(main);
    const credits = el("footer", void 0, "player-credits");
    if (logoUrl) {
      const logo = document.createElement("img");
      logo.src = safeUrl(logoUrl);
      logo.alt = "Grupo de Pesquisa Horizonte";
      credits.append(logo);
    };
    const creditText = el("div");
    const developed = el("p");
    developed.append("Desenvolvido pelo ");
    developed.append(el("strong", "professor Dr. Glauber Santiago"));
    developed.append(" — DAC/UFSCar");
    const support = el("p", "Apoio: ");
    const horizon = el(
      "a",
      "Grupo de Pesquisa Horizonte ↗"
    );
    horizon.href = "https://grupohorizonte.ufscar.br/";
    horizon.target = "_blank";
    horizon.rel = "noopener noreferrer";
    const website = el("a", "🌐 Website do Docente ↗");
    website.href = "https://servidores.ufscar.br/glauber/";
    website.target = "_blank";
    website.rel = "noopener noreferrer";
    support.append(horizon, " • ", website);
    creditText.append(developed, support);
    credits.append(creditText);
    root.append(credits);
  }
  render();
  save();
})(window.COURSE,"2004",false,'media/logo-horizonte.png');